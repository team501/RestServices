import React, { Component } from 'react';
import Header from '../../login/Header';
import UnitSorter from './Landingpage';
import Footer from '../../login/Footer';

class SorterDetailContainer extends Component {
	
	linkState = this.props.location.state === undefined ? '' : this.props.location.state.data;
		
    render(){
      return(<div>
      			<Header/>
      			<UnitSorter data={this.linkState} forcedRender={this.props.forcedRender}/>
      			<Footer />
      		</div>
      );
    }
  }
export default SorterDetailContainer;
