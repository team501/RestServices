import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';
import {Link} from 'react-router-dom';
import Assigned from './Chute/Assigned';
import AssignedPer from './Chute/AssignedPer';
import NotAssigned from './Chute/NotAssigned';
import '../land.css';
import './Chute/label.css';

import Legends from './Chute/Legends';
import Doughnut from '../../Chart2js/Doughnut';

import {baseURL} from '../../../Config.js';
import axios from 'axios';

const headingGrid = {
		
};
const mainGrid = {
		padding: '15px',
		height: '280px',
};
const bottomGrid = {
	    backgroundColor: '#F4F4F4',
	    height: '100px'
}
class index extends Component{
	
	constructor(props) {
		super(props);
		this.state = {  data: [],
						label: ['Full', 'Empty', 'Error', 'Disabled'],
						color: ['#d0021b', '#7ed321', '#f8e71c', '#9f9c9c'],
					    isLoading:true
					  };
	}
	
	componentDidUpdate(prevProps) {
		  // Typical usage (don't forget to compare props):
		  if (this.props.forcedRender !== prevProps.forcedRender) {
		    this.componentWill();
		  }
		}
	
	async componentWill() {
		axios.get(baseURL+'chutesummary/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
		 .then(res => {
		    console.log(res.data);
		    this.setState({ data: res.data,
		    				isLoading:false}); 
		}).catch(function (error) {
			console.log(error);
	  });
	}
	async componentWillMount() {
		axios.get(baseURL+'chutesummary/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
			 .then(res => {
			    console.log(res.data);
			    this.setState({ data: res.data,
			    				isLoading:false}); 
			}).catch(function (error) {
				console.log(error);
		  });
	}
	
	
	render() {
		if(this.state.isLoading) {
			return(<Grid container></Grid>);
		} else {
			return (
					<Grid container>
						<Grid className="all-header-grid" Sitem xs={12} sm={12}>
							<strong>Chute Status</strong>
						</Grid>
							
						<Grid style={mainGrid} container>	
							<Grid item xs={12} sm={6}>
								<Doughnut forcedRender={this.props.forcedRender} data={this.state.data} label={this.state.label} color={this.state.color}/>
							</Grid>
							<Grid item xs={12} sm={5}>
								<Legends data={this.state.data}/>
							</Grid>
							<Grid item xs={12} sm={1}>
								
								
								<div className="right-arrow"> 
									<Link to={{ pathname: '/chuteStatus', state: { nextLink: this.props.nextLink } }}> <span className="glyphicon glyphicon-menu-right"></span> </Link>
									</div>
							</Grid>
						</Grid>
						
						<Grid className="chute-bottom-grid" container>
							<Grid item xs={4} sm={4}>
								<Assigned value={this.state.data.assigned}/>
							</Grid>
							<Grid item xs={4} sm={4}>
								<NotAssigned value={this.state.data.notassigned} />
							</Grid>
							<Grid item xs={4} sm={4}>
								<AssignedPer value={this.state.data.assignedPercentage} />
							</Grid>
						</Grid>
					
					</Grid> );
		}
	}
}
export default index;
