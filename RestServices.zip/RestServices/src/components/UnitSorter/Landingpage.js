import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';

import InductsForDay from './InductsForTheDay';
import SortsForTheDay from './SortsForTheDay';
import InductsForlastHour from './InductsForlastHour';
import SortsForlastHour from './SortsForlastHour';
import Sorter from './Sorter';
import WaveStatus from './WaveStatus';

import {baseURL} from '../../Config.js';
import axios from 'axios';

const root = {
	    flexGrow: 1,
	    padding: '50px 20px 20px 20px'
};

const paper = {
    padding: '0px',
    height: 200
};

const paper2 = {
	    padding: '0px',
	    height: 405
	};

const headingFont = {
	    color: '#870038',
	    fontWeight: '400',
	    fontSize: '24px',
	    padding: '60px 0px 20px 0px'
};

const rightGrid = {
	    paddingLeft: '12px'
};

const leftGrid = {
	    paddingLeft: '8px'
};
	
class index extends Component {
	
	constructor(props) {
		super(props);
		this.state = {  data: [],
					    isLoading:true,
					    refresh:0
					  };
	}
	async componentDidMount() {
	    this.intervalID = setInterval(
	      () => this.tick(),
	      10000
	    );
	  }
	 componentWillUnmount() {
	    clearInterval(this.intervalID);
	  }
	 async componentWillMount(){
		 this.tick();
	 }
	 async tick() {
		  axios.get(baseURL+'sorterdata/'+ sessionStorage.getItem("username") )
			 .then(res => {
			    console.log("inside"+res.data);
			    this.setState({ data: res.data,
			    				isLoading:false,
			    				refresh:1
			    				}); 
			}).catch(function (error) {
				console.log(error);
		  });
	
		  if(this.state.refresh===1 || this.state.refresh===0){
				this.setState({ 
					
					refresh:2
					});
			}
			else if(this.state.refresh===2){
				
				this.setState({ 	
					refresh:1
					});
			}
	  }
	  

	render() { 
		if(this.state.refresh!=0){
			return(<div style={root}>
		      <Grid container spacing={8}>
		        <Grid style={headingFont} item xs={12} sm={12}>
		        	Unit Sorter Dashboard
		        </Grid>
		        
	        	 <Grid style={leftGrid} container xs={6} sm={3} spacing={8}>
		        	<Grid item xs={12} sm={12}>
		        		<Paper style={paper}>
		        			<InductsForDay sorterRoute={''} forcedRender={this.state.refresh} />
		        		</Paper>
		        	</Grid>
		        	<Grid item xs={12} sm={12}>
			        	<Paper style={paper}>
			          		<InductsForlastHour sorterRoute={''} forcedRender={this.state.refresh} />
			          	</Paper>
			        </Grid>
			        <Grid item xs={12} sm={12}>
			        	<Paper style={paper}>
			          		<SortsForTheDay forcedRender={this.state.refresh} />
			          	</Paper>
			        </Grid>
			        <Grid item xs={12} sm={12}>
			        	<Paper style={paper}>
			          		<SortsForlastHour forcedRender={this.state.refresh} />
			          	</Paper>
			        </Grid>
		      	</Grid>
		      	
		      	<Grid style={rightGrid} container xs={6} sm={9} spacing={8}>
			      	<Grid item xs={12} sm={12}>
			          <Paper style={paper}>
			          	<WaveStatus forcedRender={this.state.refresh}/>
			          </Paper>
			        </Grid>
			        {
                    this.state.data.map(data => <Grid item xs={12} sm={12}>
			          									<Paper style={paper}>
			          										<Sorter data={data} 
			          										forcedRender={this.state.refresh} />
			          										</Paper>
			          								</Grid> )
                }
		      	</Grid>
		      </Grid>
		    </div>)
		}
		else
		{
			return (
					<div style={root}>
				      <Grid container spacing={8}>
				        <Grid style={headingFont} item xs={12} sm={12}>
				        	Unit Sorter Dashboard
				        </Grid>
				        
			        	 <Grid style={leftGrid} container xs={6} sm={3} spacing={8}>
				        	<Grid item xs={12} sm={12}>
				        		<Paper style={paper}>
				        			
				        		</Paper>
				        	</Grid>
				        	<Grid item xs={12} sm={12}>
					        	<Paper style={paper}>
					          		
					          	</Paper>
					        </Grid>
					        <Grid item xs={12} sm={12}>
					        	<Paper style={paper}>
					          		
					          	</Paper>
					        </Grid>
					        <Grid item xs={12} sm={12}>
					        	<Paper style={paper}>
					          		
					          	</Paper>
					        </Grid>
				      	</Grid>
				      	
				      	<Grid style={rightGrid} container xs={6} sm={9} spacing={8}>
					      	<Grid item xs={12} sm={12}>
					          <Paper style={paper}>
					          	
					          </Paper>
					        </Grid>
					        {
                                this.state.data.map(data => <Grid item xs={12} sm={12}>
  					          									<Paper style={paper}>
  					          										
  					          										</Paper>
  					          								</Grid> )
                            }
				      	</Grid>
				      </Grid>
				    </div>
			);
		}
		 }
}

export default index;