	import React, { Component } from 'react';
import {BrowserRouter, Route, Redirect, Switch, Link} from 'react-router-dom';
import './landing.css';
import Dashboard from '../../images/dashboard.jpg';
import Manage from '../../images/manage.jpg';
import Labour from '../../images/labour.jpg';
import ManageEqe from '../../images/manage_eqe.jpg';
import Workmonotring from '../../images/work-monotring.jpg';
import ManageInvontry from '../../images/manage-invontry.jpg';
import Exception from '../../images/exceptions.jpg';
import Report from '../../images/report.jpg';

const user1Menu = [
	{ imgSource:Dashboard, label:"Dashboard"},
	{ imgSource:Manage, label:"Manage Order/Waves"},
	{ imgSource:Labour, label:"Balance Labour"},
	{ imgSource:ManageEqe, label:"Manage Equipment", link:"manageequipment"},
	{ imgSource:Workmonotring, label:"Work Monitoring"},
	{ imgSource:ManageInvontry, label:"Manage Inventory"},
	{ imgSource:Exception, label:"Exception"},
	{ imgSource:Report, label:"Report"},
];

const user2Menu = [
	{ imgSource:Dashboard, label:"Dashboard"},
	{ imgSource:Manage, label:"Manage Order/Waves"},
	{ imgSource:Labour, label:"Balance Labour"},
	{ imgSource:ManageEqe, label:"Manage Equipment", link:"manageequipment"}
];

var userName = sessionStorage.getItem("username");
class Main extends Component {
	
    render(){
      return(
		<div className="main-bg">
				<div className="main-content">
				<div className="row">
				{userName == 'Ramesh' ? (
					<ul>
						
						<li><div className="main-content-img"><img src={user1Menu[0].imgSource}/></div>
						<div className="main-content-text">{user1Menu[0].label}</div>
						</li>
						
						<li><div className="main-content-img"><img src={Manage}/></div>
						<div className="main-content-text">Manage Order/Waves</div>
						</li>
					
						<li><div className="main-content-img"><img src={Labour}/></div>
						<div className="main-content-text">Balance Labour</div>
						</li>
						
						<li><div className="main-content-img"><img src={ManageEqe}/></div>
						<div className="main-content-text"><Link to={`/manageequipment`} activeClassName="active">Manage Equipment</Link></div>
						</li>
						
						<li><div className="main-content-img"><img src={Workmonotring}/></div>
						<div className="main-content-text">Work Monitoring</div>
						</li>
						
						<li><div className="main-content-img"><img src={ManageInvontry}/></div>
						<div className="main-content-text">Manage Inventory</div>
						</li>
					
						<li><div className="main-content-img"><img src={Exception}/></div>
						<div className="main-content-text">Exceptions</div>
						</li>
					
						<li><div className="main-content-img"><img src={Report}/></div>
						<div className="main-content-text">Report</div>
						</li>
						
						</ul>
						) :(
						<ul>
						<li><div className="main-content-img"><img src={ManageEqe}/></div>
						<div className="main-content-text"><Link to={`/manageequipment`} activeClassName="active">Manage Equipment</Link></div>
						</li>
					
						<li><div className="main-content-img"><img src={Workmonotring}/></div>
						<div className="main-content-text">Work Monitoring</div>
						</li>
						
						<li><div className="main-content-img"><img src={ManageInvontry}/></div>
						<div className="main-content-text">Manage Inventory</div>
						</li>
					
						<li><div className="main-content-img"><img src={Exception}/></div>
						<div className="main-content-text">Exceptions</div>
						</li>
						
					</ul>
					)}
					</div>
				</div>
		</div>
      );
    }
  }
export default Main;
