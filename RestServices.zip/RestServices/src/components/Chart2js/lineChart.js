import React, {Component} from 'react';
import {Line} from 'react-chartjs-2';
import './land.css';

class LineChart extends Component {
	
	constructor(props) {
		super(props);
		this.state = { data: {
			  labels: this.props.label,
			  datasets: [
			    {
			      lineTension: 0,
			      backgroundColor: 'rgba(75,192,192,0)',
			      borderColor: this.props.color,
			      borderCapStyle: 'butt',
			      borderDash: [5,2],
			      borderDashOffset: 0.0,
			      borderJoinStyle: 'miter',
			      pointBorderColor: this.props.color,
			      pointBackgroundColor: this.props.color,
			      pointBorderWidth: 5,
			      pointHoverRadius: 5,
			      pointHoverBackgroundColor: 'rgba(75,192,192,1)',
			      pointHoverBorderColor: 'rgba(220,220,220,1)',
			      pointHoverBorderWidth: 1,
			      pointRadius: 1,
			      pointHitRadius: 10,
			      data: [...this.props.graphData, Math.min(...this.props.graphData) - 10]
			    }
			  ]
			}};
	}

	componentDidUpdate(prevProps, prevState) {
		  // only update chart if the data has changed
		  if (prevProps.forcedRender !== this.props.forcedRender) {
			  this.setState({ 
					  data: {
						  labels: this.props.label,
						  datasets: [
						    {
						      lineTension: 0,
						      backgroundColor: 'rgba(75,192,192,0)',
						      borderColor: this.props.color,
						      borderCapStyle: 'butt',
						      borderDash: [5,2],
						      borderDashOffset: 0.0,
						      borderJoinStyle: 'miter',
						      pointBorderColor: this.props.color,
						      pointBackgroundColor: this.props.color,
						      pointBorderWidth: 5,
						      pointHoverRadius: 5,
						      pointHoverBackgroundColor: 'rgba(75,192,192,1)',
						      pointHoverBorderColor: 'rgba(220,220,220,1)',
						      pointHoverBorderWidth: 1,
						      pointRadius: 1,
						      pointHitRadius: 10,
						      data: [...this.props.graphData, Math.min(...this.props.graphData) - 10]
						    }
						  ]
					  }
				});
		  }
	}
		  
	render() {
		return( <Line width={30}
		   			  height={40}
					  options={{ maintainAspectRatio: false,
					  legend: {
								display: false
							},
							layout: {
								padding: {
									right: 10,
									top:15
								}
							}, 
									
			scales: {
	            xAxes: [{
	            	gridLines: {
	                    color: "rgba(255, 255, 255, 0)"
	                },
	                ticks: {
	                    display: false
	                },
	                display: false 
	            }],
	            yAxes: [{
	            	gridLines: {
	                    color: "rgba(255, 255, 255, 0)"
	                },
	                ticks: {
	                    display: false
	                }
	            }]
	        }}} data={this.state.data} /> );
	}
}
export default LineChart;