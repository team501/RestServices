import React, {Component} from 'react';
import CircularProgressbar from 'react-circular-progressbar';

import 'react-circular-progressbar/dist/styles.css';


class CircularProgress extends Component {
	
	constructor(props) {
		super(props);
		this.state = {  percentage: this.props.percentage,
					  };
	}
	
	componentDidUpdate(prevProps) {
		  // Typical usage (don't forget to compare props):
		  if (this.props.percentage !== prevProps.percentage) {
			  this.setState({ percentage: this.props.percentage });
		  }
		}
		
	render() {
		return(
				<CircularProgressbar
				  percentage={this.state.percentage}
				  text={`${this.state.percentage}%`}
				  background
				  backgroundPadding={0}
				  styles={{
				    path: { stroke: `rgba(135,0,56, ${this.percentage / 100})`, strokeLinecap: 'butt' },
				    text: { fill: '#121212', fontSize: '25px' },
				    trail: { stroke: '#d7d7d7' },
				    background: {
			            fill: '#ffffff',
			          }
				  }}
				/>	
		);
	}
}
export default CircularProgress;