import React, {Component} from 'react';
import { ProgressBar } from 'react-bootstrap';

class Example extends Component {
	constructor(props) {
		super(props);
		this.state = { value: this.props.value};
	}	
	
	componentDidUpdate(prevProps, prevState) {
		  // only update chart if the data has changed
		  if (prevProps.value !== this.props.value) {
			  this.setState({value: this.props.value});
		  }
		}
	
	render() {
		return ( <div>
			    	<ProgressBar style={{height: '5px'}} bsStyle={this.props.progressColor} now={this.state.value} />
			     </div> );
	}
}

export default Example;