import React, {Component} from 'react';
import {Bar} from 'react-chartjs-2';
import axios from 'axios';

class BarChart extends Component {

	//defaultLabel = this.props.label === undefined ? ['1', '2', '3', '4', '5'] : this.props.label;
	//defaultData =  this.props.graphData === undefined ? [10, 15, 25, 15, 40] : this.props.graphData;
	//findMinimum =  Math.min(...this.defaultData) - (1);

	constructor(props) {
		super(props);
		this.state = {  data: { labels: this.props.label,
			datasets: [ { 
				backgroundColor: [
					'rgba(245, 166, 35)',
					'rgba(126, 211, 33)',
					'rgba(248, 231, 28)',
					'rgba(208, 2, 27)'

					],
					borderColor: [
						'rgba(245, 166, 35)',
						'rgba(126, 211, 33)',
						'rgba(248, 231, 28)',
						'rgba(208, 2, 27)'

						],		  			
						borderWidth: 1,
						//hoverBackgroundColor: 'rgba(255,99,132,0.4)',
						//hoverBorderColor: 'rgba(255,99,132,1)',
						data: [ ...this.props.graphData, Math.min(...this.props.graphData)-1]
			}]
		}
		};
	}

	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.forcedRender !== prevProps.forcedRender) {
			this.setState({ data: { labels: this.props.label,
				datasets: [ { 
					backgroundColor: [
						'rgba(245, 166, 35)',
						'rgba(126, 211, 33)',
						'rgba(248, 231, 28)',
						'rgba(208, 2, 27)'

						],
						borderColor: [
							'rgba(245, 166, 35)',
							'rgba(126, 211, 33)',
							'rgba(248, 231, 28)',
							'rgba(208, 2, 27)'

							],		  			
							borderWidth: 1,
							//hoverBackgroundColor: 'rgba(255,99,132,0.4)',
							//hoverBorderColor: 'rgba(255,99,132,1)',
							data: [ ...this.props.graphData, Math.min(...this.props.graphData)-1]
				}]
			}


			});
		}
	}

	render () {

		return( <div> <Bar redraw={true} data={this.state.data} width={50} height={40} options={{ maintainAspectRatio: false, legend: {
			display: false
		},scales: {
			xAxes: [{
				barPercentage: 0.1,
				ticks: {
					fontSize: 14
				},
				gridLines : {
					                display : false
					            } 
			}],
			yAxes: [{
				position: 'right',
				ticks: {
					fontSize: 12,
					fontWeight:800
				}
			}]}  }}/> </div>);
	}
}


export default BarChart;