import React from 'react';
import { ProgressBar } from 'react-bootstrap';

const Example = (props) => {
  return (
    <div>
      <ProgressBar>
      	<ProgressBar bsStyle="success" now={props.allocated} key={1} />
      	<ProgressBar bsStyle="warning" now={props.sorted} key={2} />
      	<ProgressBar bsStyle="danger" now={props.remaining} key={3} />
      </ProgressBar>
    </div>
  );
};

export default Example;