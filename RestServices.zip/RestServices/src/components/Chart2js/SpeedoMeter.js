import React, {Component} from 'react';
import ReactSpeedometer from "react-d3-speedometer"


class SpeedoMeter extends Component {
	
	constructor(props) {
		super(props);
		this.state = {  value: this.props.value,
					  };
	}
	componentDidUpdate(prevProps) {
		  // Typical usage (don't forget to compare props):
		  if (this.props.value !== prevProps.value) {
			  this.setState({ value: this.props.percentage });
		  }
		}
	
	render() {
		return(<ReactSpeedometer segments={3} 
								 width={125} 
								 height={100} 
								 ringWidth={10}
								 minValue={0} 
								 maxValue={100}
								 value={this.props.value}
								 needleHeightRatio={0.7}
								 textColor=" rgba(255, 255, 255, 0)"
				/>);
	}
}
export default SpeedoMeter;